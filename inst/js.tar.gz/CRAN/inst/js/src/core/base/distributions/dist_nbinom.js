// // Negative Binomial
// dnbinom(x, size, prob, mu, log = FALSE)
// pnbinom(q, size, prob, mu, lower.tail = TRUE, log.p = FALSE)
// qnbinom(p, size, prob, mu, lower.tail = TRUE, log.p = FALSE)
// rnbinom(n, size, prob, mu)
