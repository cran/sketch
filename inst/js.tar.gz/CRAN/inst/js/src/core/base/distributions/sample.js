// function sample(x, size, replace = FALSE, prob = NULL) {

// }
